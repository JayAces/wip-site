// wip-scene.jsx — Warrior Intelligence Project explainer animation
// Colors matched to warriorintelligenceproject.org screenshots
const { CompositionStage, useComposition, Shot, Captions, Easing, interpolate, animate, clamp } = window;

// Site palette from screenshots
const GOLD = '#D4A853';
const GOLD_LIGHT = '#E8C472';
const ORANGE = '#C41E3A';      // CTA / accent red from site
const RED = '#C41E3A';         // same red used throughout
const BG = '#0B1426';          // dark navy from dashboard
const BG_CARD = '#111D30';
const BG_LIGHT = '#1A2840';
const TEXT = '#F0EDE6';
const TEXT_DIM = '#7A8899';
const TEAL = '#2DD4A8';        // teal buttons from dashboard
const GREEN = '#3AA676';
const TALLY_YELLOW = '#F5B731'; // Tally form header

const MOTION = {
  enter: (T, start, dur = 0.6) => {
    const t = clamp((T - start) / dur, 0, 1);
    return Easing.easeOutCubic(t);
  },
  draw: (T, start, dur = 0.8) => {
    const t = clamp((T - start) / dur, 0, 1);
    return Easing.easeInOutCubic(t);
  },
  pop: (T, start, dur = 0.4) => {
    const t = clamp((T - start) / dur, 0, 1);
    return Easing.easeOutBack(t);
  }
};

// WIP Logo component using actual logo image
function WIPLogo({ size = 120, glow = 0 }) {
  return React.createElement('img', {
    src: './wip-logo.png',
    width: size, height: size,
    style: {
      objectFit: 'contain', borderRadius: 8,
      filter: glow > 0 ? `drop-shadow(0 0 ${glow}px ${GOLD})` : 'none'
    }
  });
}

// Small logo for headers
function WIPLogoSmall({ size = 28 }) {
  return React.createElement('img', {
    src: './wip-logo.png',
    width: size, height: size,
    style: { objectFit: 'contain', borderRadius: 4 }
  });
}

function PulseRing({ T, start, x, y, color = GOLD, delay = 0 }) {
  const p = MOTION.enter(T, start + delay, 1.5);
  const scale = 0.5 + p * 1.5;
  const opacity = Math.max(0, 1 - p);
  return React.createElement('div', {
    style: {
      position: 'absolute', left: x, top: y,
      width: 140, height: 140, borderRadius: '50%',
      border: `1.5px solid ${color}`, transform: `translate(-50%,-50%) scale(${scale})`,
      opacity: opacity * 0.4, pointerEvents: 'none'
    }
  });
}

function DataBar({ T, start, width, label, delay = 0, color = GOLD }) {
  const p = MOTION.draw(T, start + delay, 0.6);
  return React.createElement('div', { style: { marginBottom: 12 } },
    React.createElement('div', {
      style: {
        display: 'flex', justifyContent: 'space-between', alignItems: 'center',
        fontSize: 11, color: TEXT_DIM, marginBottom: 5, fontWeight: 500, letterSpacing: 0.3
      }
    },
      React.createElement('span', null, label),
      React.createElement('span', { style: { color: color, fontWeight: 700, fontSize: 12 } },
        `${Math.round(width * p)}%`
      )
    ),
    React.createElement('div', {
      style: { height: 6, borderRadius: 3, background: BG_LIGHT, overflow: 'hidden' }
    },
      React.createElement('div', {
        style: {
          height: '100%', borderRadius: 3,
          background: `linear-gradient(90deg, ${color}, ${color}cc)`,
          width: `${width * p}%`
        }
      })
    )
  );
}

function FormField({ label, T, start, delay = 0, filled = false }) {
  const p = MOTION.enter(T, start + delay, 0.5);
  const fillP = filled ? MOTION.draw(T, start + delay + 0.8, 0.4) : 0;
  return React.createElement('div', {
    style: { opacity: p, transform: `translateY(${(1 - p) * 12}px)`, marginBottom: 14 }
  },
    React.createElement('div', {
      style: {
        fontSize: 10, color: TEXT_DIM, marginBottom: 4, fontWeight: 600,
        letterSpacing: 0.8, textTransform: 'uppercase'
      }
    }, label),
    React.createElement('div', {
      style: {
        height: 34, borderRadius: 6, border: `1px solid ${fillP > 0.5 ? GOLD + '60' : BG_LIGHT}`,
        background: fillP > 0.5 ? GOLD + '08' : 'rgba(255,255,255,0.02)'
      }
    })
  );
}

function StatPill({ value, label, T, start, delay = 0, color = GOLD }) {
  const p = MOTION.pop(T, start + delay, 0.5);
  return React.createElement('div', {
    style: { textAlign: 'center', opacity: p, transform: `scale(${0.8 + p * 0.2})` }
  },
    React.createElement('div', {
      style: { fontSize: 32, fontWeight: 800, color: color, lineHeight: 1 }
    }, value),
    React.createElement('div', {
      style: {
        fontSize: 11, color: TEXT_DIM, marginTop: 6, fontWeight: 600,
        letterSpacing: 1.5, textTransform: 'uppercase', lineHeight: 1.2
      }
    }, label)
  );
}

function WIPAnimation() {
  const { T, CUES } = useComposition();

  const cIntro = CUES.Intro || 0;
  const cMission = CUES.Mission || 3;
  const cProcess = CUES.Process || 8;
  const cDashboard = CUES.Dashboard || 14;
  const cCTA = CUES.CTA || 19;

  const bgY = T * -2;

  React.useEffect(() => {
    const el = document.querySelector('[data-om-exportable-video-with-duration-secs]');
    if (el) el.setAttribute('data-screen-label', `t=${Math.floor(T)}s`);
  }, [Math.floor(T)]);

  return React.createElement('div', {
    style: {
      width: 1080, height: 1920, overflow: 'hidden', position: 'relative',
      background: BG, fontFamily: "'Urbanist', sans-serif", color: TEXT
    }
  },
    // Subtle radial glow
    React.createElement('div', {
      style: {
        position: 'absolute', inset: 0,
        backgroundImage: `radial-gradient(ellipse 60% 40% at 50% 35%, ${GOLD}0A 0%, transparent 70%)`,
        transform: `translateY(${bgY}px)`
      }
    }),
    // Fine grid
    React.createElement('div', {
      style: {
        position: 'absolute', inset: 0, opacity: 0.025,
        backgroundImage: `radial-gradient(${TEXT} 0.5px, transparent 0.5px)`,
        backgroundSize: '28px 28px', transform: `translateY(${bgY * 0.3}px)`
      }
    }),

    // === SCENE 1: INTRO ===
    React.createElement(Shot, { from: cIntro, to: cMission + 1.5 },
      (() => {
        const logoP = MOTION.pop(T, cIntro + 0.3, 0.7);
        const titleP = MOTION.enter(T, cIntro + 0.8, 0.6);
        const subP = MOTION.enter(T, cIntro + 1.3, 0.5);
        const fadeOut = 1 - MOTION.enter(T, cMission - 0.4, 0.5);
        return React.createElement('div', {
          style: {
            position: 'absolute', inset: 0, display: 'flex', flexDirection: 'column',
            alignItems: 'center', justifyContent: 'center', opacity: fadeOut,
            transform: `scale(${1 + (1 - fadeOut) * 0.03})`
          }
        },
          React.createElement(PulseRing, { T, start: cIntro + 0.4, x: '50%', y: '38%', color: GOLD }),
          React.createElement(PulseRing, { T, start: cIntro + 0.4, x: '50%', y: '38%', color: GOLD, delay: 0.5 }),
          // Actual WIP logo
          React.createElement('div', {
            style: {
              transform: `scale(${logoP})`, opacity: logoP, marginBottom: 32
            }
          }, React.createElement(WIPLogo, { size: 200, glow: 20 * logoP })),
          // Badge
          React.createElement('div', {
            style: {
              fontSize: 11, color: GOLD, letterSpacing: 3, textTransform: 'uppercase',
              fontWeight: 700, opacity: subP,
              padding: '6px 16px', borderRadius: 20,
              border: `1px solid ${GOLD}30`, background: `${GOLD}08`
            }
          }, 'Real-Time Crisis Intelligence · Community-Owned')
        );
      })()
    ),

    // === SCENE 2: MISSION ===
    React.createElement(Shot, { from: cMission - 0.4, to: cProcess + 0.3 },
      (() => {
        const enterP = MOTION.enter(T, cMission, 0.6);
        const line1 = MOTION.enter(T, cMission + 0.4, 0.5);
        const line2 = MOTION.enter(T, cMission + 1.0, 0.5);
        const line3 = MOTION.enter(T, cMission + 1.6, 0.5);
        const highlight = MOTION.draw(T, cMission + 2.2, 0.6);
        const fadeOut = 1 - MOTION.enter(T, cProcess - 0.5, 0.5);
        return React.createElement('div', {
          style: {
            position: 'absolute', inset: 0, display: 'flex', flexDirection: 'column',
            alignItems: 'center', justifyContent: 'center', padding: '0 80px',
            opacity: enterP * fadeOut
          }
        },
          // Gold accent line
          React.createElement('div', {
            style: {
              width: 50, height: 3, background: ORANGE, borderRadius: 2,
              marginBottom: 36, transform: `scaleX(${line1})`, transformOrigin: 'center'
            }
          }),
          React.createElement('div', {
            style: {
              fontSize: 34, fontWeight: 600, lineHeight: 1.4, textAlign: 'center',
              opacity: line1, transform: `translateY(${(1 - line1) * 16}px)`
            }
          }, 'Learn your patterns'),
          React.createElement('div', {
            style: {
              fontSize: 26, fontWeight: 400, lineHeight: 1.4, textAlign: 'center',
              color: TEXT_DIM, marginTop: 10, opacity: line2,
              transform: `translateY(${(1 - line2) * 16}px)`
            }
          }, 'before they become'),
          React.createElement('div', {
            style: {
              fontSize: 40, fontWeight: 800, lineHeight: 1.3, textAlign: 'center',
              marginTop: 10, opacity: line3, transform: `translateY(${(1 - line3) * 16}px)`,
              position: 'relative'
            }
          },
            React.createElement('span', { style: { position: 'relative', zIndex: 1 } }, 'emergencies.'),
            React.createElement('div', {
              style: {
                position: 'absolute', bottom: 0, left: '5%', right: '5%',
                height: 12, background: ORANGE, opacity: 0.35, borderRadius: 2,
                transform: `scaleX(${highlight})`, transformOrigin: 'left'
              }
            })
          ),
          // Real stats from site — matching their layout
          React.createElement('div', {
            style: {
              display: 'flex', gap: 28, marginTop: 56,
              opacity: MOTION.enter(T, cMission + 2.8, 0.6)
            }
          },
            React.createElement(StatPill, { value: '115+', label: 'Warriors', T, start: cMission + 2.8, color: GOLD }),
            React.createElement('div', { style: { width: 1, background: BG_LIGHT, alignSelf: 'stretch' } }),
            React.createElement(StatPill, { value: '26', label: 'U.S. States', T, start: cMission + 2.8, delay: 0.15, color: GOLD }),
            React.createElement('div', { style: { width: 1, background: BG_LIGHT, alignSelf: 'stretch' } }),
            React.createElement(StatPill, { value: '78%', label: 'In Crisis', T, start: cMission + 2.8, delay: 0.3, color: RED }),
          )
        );
      })()
    ),

    // === SCENE 3: PROCESS (Tally form style) ===
    React.createElement(Shot, { from: cProcess - 0.3, to: cDashboard + 0.3 },
      (() => {
        const enterP = MOTION.enter(T, cProcess, 0.6);
        const fadeOut = 1 - MOTION.enter(T, cDashboard - 0.5, 0.5);
        const phoneP = MOTION.enter(T, cProcess + 0.2, 0.6);
        const submitP = MOTION.pop(T, cProcess + 3, 0.5);
        const checkP = MOTION.pop(T, cProcess + 4, 0.5);
        const timerP = MOTION.draw(T, cProcess + 0.5, 3.5);
        return React.createElement('div', {
          style: {
            position: 'absolute', inset: 0, display: 'flex', flexDirection: 'column',
            alignItems: 'center', justifyContent: 'center',
            opacity: enterP * fadeOut
          }
        },
          React.createElement('div', {
            style: {
              fontSize: 11, color: GOLD, letterSpacing: 3, textTransform: 'uppercase',
              fontWeight: 700, marginBottom: 14, opacity: enterP,
              padding: '5px 14px', borderRadius: 16,
              border: `1px solid ${GOLD}25`, background: `${GOLD}06`
            }
          }, 'How it works'),
          React.createElement('div', {
            style: {
              fontSize: 26, fontWeight: 700, textAlign: 'center', marginBottom: 28,
              opacity: enterP, transform: `translateY(${(1 - enterP) * 12}px)`
            }
          }, 'Log your crisis in under 3 minutes'),
          // Phone mockup with Tally-style form
          React.createElement('div', {
            style: {
              width: 340, background: '#fff', borderRadius: 28, overflow: 'hidden',
              position: 'relative',
              transform: `translateY(${(1 - phoneP) * 30}px) scale(${0.92 + phoneP * 0.08})`,
              opacity: phoneP, boxShadow: `0 24px 64px rgba(0,0,0,0.5)`
            }
          },
            // Notch
            React.createElement('div', {
              style: {
                position: 'absolute', top: 8, left: '50%', transform: 'translateX(-50%)',
                width: 70, height: 5, borderRadius: 3, background: '#e0e0e0', zIndex: 2
              }
            }),
            // Tally-style yellow header with logo
            React.createElement('div', {
              style: {
                background: TALLY_YELLOW, padding: '36px 20px 16px', display: 'flex',
                flexDirection: 'column', alignItems: 'center', gap: 8
              }
            },
              React.createElement('div', {
                style: { fontSize: 14, fontWeight: 800, color: '#1a1a1a', letterSpacing: 0.3 }
              }, 'Warrior Intelligence Tracker'),
              React.createElement('div', {
                style: { fontSize: 10, color: '#5a5a5a' }
              }, 'Accepting submissions now · warriorintelligenceproject.org')
            ),
            // Anonymous bar
            React.createElement('div', {
              style: {
                background: `${TALLY_YELLOW}30`, padding: '8px 20px',
                fontSize: 10, color: '#6a5a00', fontWeight: 600, letterSpacing: 0.3,
                borderBottom: '1px solid #eee'
              }
            }, '🔒 Anonymous · Never linked to your identity'),
            // Form body
            React.createElement('div', {
              style: { padding: '16px 20px', color: '#1a1a1a' }
            },
              // Consent text
              React.createElement('div', {
                style: {
                  fontSize: 10, color: '#666', lineHeight: 1.5, marginBottom: 14,
                  opacity: MOTION.enter(T, cProcess + 0.3, 0.4)
                }
              }, 'I understand and agree that my anonymous responses may be used for community reports...'),
              // Fields
              React.createElement('div', {
                style: { opacity: MOTION.enter(T, cProcess + 0.6, 0.4) }
              },
                React.createElement('div', { style: { fontSize: 10, color: '#999', marginBottom: 3, fontWeight: 600, textTransform: 'uppercase', letterSpacing: 0.5 } }, 'Pain Level (1-10)'),
                React.createElement('div', { style: { height: 30, borderRadius: 4, border: '1px solid #ddd', marginBottom: 10 } })
              ),
              React.createElement('div', {
                style: { opacity: MOTION.enter(T, cProcess + 0.9, 0.4) }
              },
                React.createElement('div', { style: { fontSize: 10, color: '#999', marginBottom: 3, fontWeight: 600, textTransform: 'uppercase', letterSpacing: 0.5 } }, 'Triggers'),
                React.createElement('div', { style: { height: 30, borderRadius: 4, border: '1px solid #ddd', marginBottom: 10 } })
              ),
              React.createElement('div', {
                style: { opacity: MOTION.enter(T, cProcess + 1.2, 0.4) }
              },
                React.createElement('div', { style: { fontSize: 10, color: '#999', marginBottom: 3, fontWeight: 600, textTransform: 'uppercase', letterSpacing: 0.5 } }, 'Create Warrior ID'),
                React.createElement('div', { style: { height: 30, borderRadius: 4, border: '1px solid #ddd', marginBottom: 10 } })
              ),
              // Submit button
              React.createElement('div', {
                style: {
                  marginTop: 8, height: 38, borderRadius: 6,
                  background: checkP > 0.5 ? GREEN : '#1a1a1a',
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  fontSize: 13, fontWeight: 700, letterSpacing: 0.5, color: '#fff',
                  transform: `scale(${submitP})`, opacity: submitP
                }
              }, checkP > 0.5 ? '✓ Submitted' : 'Next →'),
              // Made with Tally
              React.createElement('div', {
                style: {
                  marginTop: 10, fontSize: 9, color: '#bbb', textAlign: 'center',
                  opacity: submitP
                }
              }, 'Made with Tally')
            )
          ),
          // Go to Dashboard callout
          checkP > 0.5 && React.createElement('div', {
            style: {
              marginTop: 20, padding: '10px 20px', borderRadius: 10,
              background: `${ORANGE}18`, border: `1px solid ${ORANGE}40`,
              display: 'flex', alignItems: 'center', gap: 10,
              opacity: MOTION.enter(T, cProcess + 4.5, 0.4)
            }
          },
            React.createElement('span', { style: { fontSize: 14 } }, '⚠️'),
            React.createElement('span', { style: { fontSize: 12, color: TEXT } },
              'Once complete, log in with your Warrior ID'
            )
          )
        );
      })()
    ),

    // === SCENE 4: DASHBOARD — Community Patterns data view ===
    React.createElement(Shot, { from: cDashboard - 0.3, to: cCTA + 0.3 },
      (() => {
        const PURPLE = '#B060D0';
        const YELLOW = '#F5B731';
        const enterP = MOTION.enter(T, cDashboard, 0.6);
        const fadeOut = 1 - MOTION.enter(T, cCTA - 0.5, 0.5);
        const dashP = MOTION.enter(T, cDashboard + 0.3, 0.6);
        const statsP = MOTION.enter(T, cDashboard + 0.8, 0.5);
        const triggersP = MOTION.enter(T, cDashboard + 2.0, 0.6);
        const insightP = MOTION.enter(T, cDashboard + 3.0, 0.5);
        const zoom = 1 + MOTION.draw(T, cDashboard + 0.5, 4) * 0.04;
        // Stat card helper
        const StatCard = (val, label, sub, color, delay) => {
          const p = MOTION.pop(T, cDashboard + 0.8 + delay, 0.5);
          return React.createElement('div', {
            style: {
              flex: 1, padding: '12px 8px', borderRadius: 10, border: `1px solid ${BG_LIGHT}`,
              background: BG_CARD, textAlign: 'center',
              opacity: p, transform: `scale(${0.85 + p * 0.15})`
            }
          },
            React.createElement('div', { style: { fontSize: 22, fontWeight: 900, color: color } }, val),
            React.createElement('div', { style: { fontSize: 9, color: TEXT_DIM, marginTop: 2, fontWeight: 600 } }, label),
            sub && React.createElement('div', { style: { fontSize: 8, color: TEXT_DIM, marginTop: 1 } }, sub)
          );
        };
        // Trigger bar helper
        const TriggerBar = (name, count, pct, width, delay, badge) => {
          const p = MOTION.draw(T, cDashboard + 2.0 + delay, 0.4);
          return React.createElement('div', {
            style: { marginBottom: 8, opacity: MOTION.enter(T, cDashboard + 2.0 + delay, 0.3) }
          },
            React.createElement('div', {
              style: { display: 'flex', justifyContent: 'space-between', fontSize: 10, marginBottom: 3 }
            },
              React.createElement('div', { style: { display: 'flex', gap: 6, alignItems: 'center' } },
                React.createElement('span', { style: { color: TEXT, fontWeight: 600 } }, name),
                badge && React.createElement('span', {
                  style: { fontSize: 7, padding: '1px 5px', borderRadius: 3, background: PURPLE, color: '#fff', fontWeight: 700, letterSpacing: 0.3 }
                }, badge)
              ),
              React.createElement('span', { style: { color: TEXT_DIM } }, `${count} (${pct}%)`)
            ),
            React.createElement('div', { style: { height: 4, borderRadius: 2, background: BG_LIGHT, overflow: 'hidden' } },
              React.createElement('div', { style: { height: '100%', borderRadius: 2, background: TEAL, width: `${width * p}%` } })
            )
          );
        };
        return React.createElement('div', {
          style: {
            position: 'absolute', inset: 0, display: 'flex', flexDirection: 'column',
            alignItems: 'center', justifyContent: 'center',
            opacity: enterP * fadeOut, transform: `scale(${zoom})`
          }
        },
          React.createElement('div', {
            style: {
              width: 480, background: BG, borderRadius: 20,
              border: `1px solid ${BG_LIGHT}`, opacity: dashP,
              transform: `translateY(${(1 - dashP) * 20}px)`,
              boxShadow: `0 24px 64px rgba(0,0,0,0.5)`, overflow: 'hidden'
            }
          },
            // Header bar
            React.createElement('div', {
              style: { display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '12px 18px', borderBottom: `1px solid ${BG_LIGHT}` }
            },
              React.createElement('div', { style: { display: 'flex', alignItems: 'center', gap: 8 } },
                React.createElement(WIPLogoSmall, { size: 22 }),
                React.createElement('div', null,
                  React.createElement('div', { style: { fontSize: 9, color: TEXT_DIM, letterSpacing: 2, textTransform: 'uppercase', fontWeight: 600 } }, 'Human Intelligence Infrastructure'),
                  React.createElement('div', { style: { fontSize: 15, fontWeight: 800 } },
                    React.createElement('span', { style: { color: TEXT } }, 'Warrior Intelligence '),
                    React.createElement('span', { style: { color: RED } }, 'Dashboard')
                  )
                )
              ),
              React.createElement('div', { style: { fontSize: 9, color: TEAL, fontWeight: 700 } }, '● LIVE')
            ),
            // Tabs
            React.createElement('div', {
              style: { display: 'flex', gap: 16, padding: '10px 18px', borderBottom: `1px solid ${BG_LIGHT}` }
            },
              React.createElement('span', { style: { fontSize: 11, color: TEXT_DIM } }, 'My Timeline'),
              React.createElement('span', { style: { fontSize: 11, fontWeight: 700, color: TEXT, borderBottom: `2px solid ${TEXT}`, paddingBottom: 8 } }, 'Community Patterns'),
              React.createElement('span', { style: { fontSize: 11, color: TEXT_DIM } }, 'ER Accountability')
            ),
            // Stats row
            React.createElement('div', {
              style: { display: 'flex', gap: 6, padding: '14px 16px 0', flexWrap: 'wrap' }
            },
              StatCard('130', 'Total Reports', 'Dec 2025 – present', TEAL, 0),
              StatCard('6.5', 'Avg Pain', 'Across all crises', TEAL, 0.1),
              StatCard('66', 'ER Visits', null, TEAL, 0.2),
              StatCard('32%', 'Protocol Violations', '21 of 66 ER visits', RED, 0.3),
              StatCard('23%', 'Menstrual Trigger', '30 Warriors', PURPLE, 0.4)
            ),
            // 3.7x outcome gap
            React.createElement('div', {
              style: {
                margin: '8px 16px 0', padding: '10px 12px', borderRadius: 10,
                border: `1px solid ${BG_LIGHT}`, background: BG_CARD, display: 'inline-flex',
                flexDirection: 'column', alignItems: 'center',
                opacity: MOTION.pop(T, cDashboard + 1.5, 0.4)
              }
            },
              React.createElement('div', { style: { fontSize: 22, fontWeight: 900, color: YELLOW } }, '3.7×'),
              React.createElement('div', { style: { fontSize: 9, color: TEXT_DIM, fontWeight: 600 } }, 'Outcome Gap'),
              React.createElement('div', { style: { fontSize: 8, color: TEXT_DIM } }, 'Admitted vs. treat-and-release')
            ),
            // Crisis Triggers
            React.createElement('div', {
              style: { padding: '14px 18px', opacity: triggersP }
            },
              React.createElement('div', { style: { fontSize: 14, fontWeight: 800, color: TEXT, marginBottom: 4 } }, 'Crisis Triggers'),
              React.createElement('div', { style: { fontSize: 9, color: TEXT_DIM, marginBottom: 10 } }, 'Reported 24–48 hrs before onset'),
              TriggerBar('Thermal Shock', 80, 62, 100, 0),
              TriggerBar('High Stress', 70, 54, 87, 0.1),
              TriggerBar('Lack of Sleep', 47, 36, 58, 0.2),
              TriggerBar('Menstrual Cycle', 30, 23, 37, 0.3, 'COMMUNITY IDENTIFIED')
            ),
            // Insight card
            React.createElement('div', {
              style: {
                margin: '0 16px 14px', padding: '12px 14px', borderRadius: 10,
                border: `1px solid ${RED}30`, background: `${RED}08`,
                opacity: insightP
              }
            },
              React.createElement('div', { style: { fontSize: 12, fontWeight: 800, color: RED, marginBottom: 4, fontStyle: 'italic' } },
                'Systemic Pattern: Addict Stigma'
              ),
              React.createElement('div', { style: { fontSize: 10, color: TEXT_DIM, lineHeight: 1.5 } },
                '32% of ER visits ended in protocol violations — clinical teams citing addiction risk over lived experience.'
              )
            )
          )
        );
      })()
    ),

    // === SCENE 5: CTA ===
    React.createElement(Shot, { from: cCTA - 0.3, to: Infinity },
      (() => {
        const enterP = MOTION.enter(T, cCTA, 0.6);
        const urlP = MOTION.enter(T, cCTA + 0.6, 0.5);
        const tagP = MOTION.enter(T, cCTA + 1.4, 0.5);
        const word1 = MOTION.pop(T, cCTA + 2.0, 0.4);
        const word2 = MOTION.pop(T, cCTA + 2.4, 0.4);
        const word3 = MOTION.pop(T, cCTA + 2.8, 0.4);
        const glowPulse = 0.5 + Math.sin(T * 2) * 0.3;
        return React.createElement('div', {
          style: {
            position: 'absolute', inset: 0, display: 'flex', flexDirection: 'column',
            alignItems: 'center', justifyContent: 'center', opacity: enterP
          }
        },
          React.createElement(PulseRing, { T, start: cCTA, x: '50%', y: '32%', color: GOLD }),
          React.createElement(PulseRing, { T, start: cCTA, x: '50%', y: '32%', color: GOLD, delay: 0.5 }),
          React.createElement(PulseRing, { T, start: cCTA, x: '50%', y: '32%', color: GOLD, delay: 1.0 }),
          // Logo
          React.createElement('div', {
            style: { transform: `scale(${enterP})`, opacity: enterP, marginBottom: 36 }
          }, React.createElement(WIPLogo, { size: 160, glow: 20 * glowPulse })),
          // CTA button (matching site's orange button)
          React.createElement('div', {
            style: {
              fontSize: 18, fontWeight: 700, textAlign: 'center',
              opacity: urlP, transform: `translateY(${(1 - urlP) * 16}px)`,
              padding: '14px 32px', borderRadius: 10,
              background: ORANGE, color: '#fff',
              boxShadow: `0 4px 20px ${ORANGE}40`
            }
          }, 'Log Your Crisis →'),
          // URL
          React.createElement('div', {
            style: {
              fontSize: 15, color: TEXT_DIM, marginTop: 16,
              opacity: tagP, textAlign: 'center'
            }
          }, 'warriorintelligenceproject.org'),
          // Sub
          React.createElement('div', {
            style: {
              fontSize: 14, color: TEXT_DIM, marginTop: 20,
              opacity: tagP, textAlign: 'center', lineHeight: 1.5
            }
          }, 'Start learning your patterns today'),
          // Tagline — matching site typography
          React.createElement('div', {
            style: {
              display: 'flex', flexDirection: 'column', alignItems: 'flex-start',
              marginTop: 50, gap: 4
            }
          },
            React.createElement('span', {
              style: {
                fontSize: 36, fontWeight: 900, opacity: word1,
                transform: `translateX(${(1 - word1) * -30}px)`, color: TEXT
              }
            }, 'Our Pain.'),
            React.createElement('span', {
              style: {
                fontSize: 36, fontWeight: 900, opacity: word2,
                transform: `translateX(${(1 - word2) * -30}px)`, color: GOLD
              }
            }, 'Our Data.'),
            React.createElement('span', {
              style: {
                fontSize: 36, fontWeight: 900, opacity: word3,
                transform: `translateX(${(1 - word3) * -30}px)`, color: ORANGE
              }
            }, 'Our Power.')
          ),
          // Footer
          React.createElement('div', {
            style: {
              position: 'absolute', bottom: 70, fontSize: 11, color: TEXT_DIM,
              opacity: MOTION.enter(T, cCTA + 3.5, 0.5), textAlign: 'center',
              letterSpacing: 0.3, lineHeight: 1.6
            }
          }, '© 2026 Jason Robert Moore', React.createElement('br'),
            'Kindred Compass Holdings, LLC'
          )
        );
      })()
    ),

    // Captions
    React.createElement(Captions, {
      style: {
        position: 'absolute', bottom: 100, left: 50, right: 50,
        textAlign: 'center', fontSize: 17, fontWeight: 600,
        color: TEXT, textShadow: `0 2px 16px ${BG}`,
        lineHeight: 1.4
      },
      items: [
        { at: cIntro + 0.5, until: cMission - 0.3, text: 'Welcome to the Warrior Intelligence Project' },
        { at: cMission + 0.3, until: cMission + 2, text: 'A platform built by warriors' },
        { at: cMission + 2, until: cProcess - 0.5, text: 'Learn your patterns before they become emergencies' },
        { at: cProcess + 0.3, until: cProcess + 2.5, text: 'Fill out the tracker in under 3 minutes' },
        { at: cProcess + 2.5, until: cProcess + 4.5, text: 'Create your Warrior ID and hit Submit' },
        { at: cDashboard + 0.3, until: cDashboard + 2, text: 'Log in with your Warrior ID' },
        { at: cDashboard + 2, until: cCTA - 0.5, text: "That's where the magic happens" },
        { at: cCTA + 0.5, until: cCTA + 1.8, text: 'Head to warriorintelligenceproject.org' },
        { at: cCTA + 1.8, text: 'Our pain. Our data. Our power.' }
      ]
    })
  );
}

// Tweaks wrapper
function WIPWithTweaks() {
  const [t, setTweak] = useTweaks(window.TWEAK_DEFAULTS);
  return React.createElement(React.Fragment, null,
    React.createElement(WIPAnimation),
    React.createElement(TweaksPanel, null,
      React.createElement(TweakToggle, {
        label: 'Motion editor', value: t.motionEditor,
        onChange: (v) => setTweak('motionEditor', v)
      })
    )
  );
}

window.WIPAnimation = WIPAnimation;
window.WIPWithTweaks = WIPWithTweaks;
